package proyectoaula.objects;
import java.util.ArrayList;
public class Usuario {
  public String nombre; 
  public String apellido; 
  public String nroDocumento;
  public String contraseña;
  public String email;   
  public String telefono; 
  public ArrayList<Gastos> listaGasto;
}
