/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoaula.objects;

import java.util.Date;

/**
 *
 * @author MELANY
 */
public class Gastos {
    public Integer id; 
    public String nombre; 
    public float valor; 
    public Date fecha; 
    public String descripcion;
    public Usuario usuario;
}
