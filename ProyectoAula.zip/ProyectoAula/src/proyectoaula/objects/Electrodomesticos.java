package proyectoaula.objects;
public class Electrodomesticos {
    public String nombreE; 
    public String nroserie;
    public String marca;
    public Usuario usuario; 
    public Gastos gasto;
}
